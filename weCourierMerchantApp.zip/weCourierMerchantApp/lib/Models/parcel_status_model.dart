class ParcelStatusModel {
  int? id;
  String? status;

  ParcelStatusModel({this.id, this.status});

  ParcelStatusModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['status'] = this.status;
    return data;
  }
}